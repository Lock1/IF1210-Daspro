Tugas Besar Dasar Pemrograman
Kelas / Kelompok : 05 / 13
- Jalankan program willy.py
- Jika print menu terlihat tidak terstruktur, ganti konfigurasi pada config.ini atau perbesar windows
- Jalankan script (ekstensi .bat) install untuk memindahkan folder ke struktur direktori program yang dapat dijalankan
- Note: script install hanya dapat dijalankan sekali 
- Program ini juga terdapat pada public repository
github.com/Lock1/tbdaspro/

- Struktur direktori ketika dijalankan
willy.py
readme.md

tools
|config.ini
|plainCSVtoHashedCSV.py

database
|user.csv
|wahana.csv
|pembelian.csv
|penggunaan.csv
|tiket.csv
|refund.csv
|kritiksaran.csv
|kehilangan.csv

package
|images
||loadfile.gif
||mainmenu.gif
|
|.gitignore.txt
|addwahana.py
|base.py
|bestwahana.py
|buyticket.py
|caripemain.py
|cariwahana.py
|exitmodule.py
|kehilangan.py
|kritiksaran.py
|load.py
|login.py
|readkritiksaran.py
|readtiket.py
|readwahana.py
|refund.py
|save.py
|signup.py
